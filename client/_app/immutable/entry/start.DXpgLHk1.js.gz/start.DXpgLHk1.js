import{c as s}from"../chunks/BqnRJcZ7.js";import{y as t}from"../chunks/DGqZX-Fr.js";export{t as load_css,s as start};
