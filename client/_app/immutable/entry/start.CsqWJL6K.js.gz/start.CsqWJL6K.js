import{c as s}from"../chunks/Bu5Fj58j.js";import{y as t}from"../chunks/CZLX4HTG.js";export{t as load_css,s as start};
