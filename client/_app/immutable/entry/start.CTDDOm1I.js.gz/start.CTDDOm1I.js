import{c as s}from"../chunks/CMM3Q6sT.js";import{y as t}from"../chunks/DkxlJsYr.js";export{t as load_css,s as start};
