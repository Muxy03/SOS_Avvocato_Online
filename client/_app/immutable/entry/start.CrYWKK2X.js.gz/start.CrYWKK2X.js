import{c as s}from"../chunks/dSJZ5dLC.js";import{y as t}from"../chunks/Nr_qU2nG.js";export{t as load_css,s as start};
