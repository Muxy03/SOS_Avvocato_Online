import{l as o,d as r}from"../chunks/CgQPfSTX.js";export{o as load_css,r as start};
