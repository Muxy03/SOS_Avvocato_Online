import{a}from"./D50pdiVl.js";const e=a({value:!0}),n=a({value:"ITA"});export{n as L,e as O};
