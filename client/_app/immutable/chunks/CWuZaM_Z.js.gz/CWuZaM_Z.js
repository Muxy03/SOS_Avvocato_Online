import{n as a,p as n}from"./D3IBXPmk.js";const p=n,s=a;export{s as n,p};
