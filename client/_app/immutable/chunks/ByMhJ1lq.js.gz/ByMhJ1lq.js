import{a7 as a}from"./nGUMutCJ.js";a();
