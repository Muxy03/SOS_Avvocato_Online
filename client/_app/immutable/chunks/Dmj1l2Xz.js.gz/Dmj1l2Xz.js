import{D as a}from"./Dkbj-q8P.js";a();
