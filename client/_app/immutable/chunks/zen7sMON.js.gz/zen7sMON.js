import{k as a}from"./CB0GAoS5.js";a();
