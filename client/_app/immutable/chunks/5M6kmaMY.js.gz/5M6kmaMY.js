import{m as a}from"./D50pdiVl.js";a();
