import{a}from"./CB0GAoS5.js";const e=a({value:!0}),n=a({value:"ITA"});export{n as L,e as O};
