import{Z as a}from"./7vUO3RyR.js";a();
