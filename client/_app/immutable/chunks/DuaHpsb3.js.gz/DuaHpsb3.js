const e=""+new URL("../assets/LOGO.BlY80MwE.jpeg",import.meta.url).href;export{e as l};
