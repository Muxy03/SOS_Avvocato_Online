import{D as a}from"./D7Q30rfQ.js";a();
