import{k as a}from"./hMZFjhjB.js";a();
