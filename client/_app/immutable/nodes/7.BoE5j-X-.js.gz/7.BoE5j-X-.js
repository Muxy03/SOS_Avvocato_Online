import"../chunks/DsnmJJEf.js";import"../chunks/5M6kmaMY.js";import{f as p,b as t}from"../chunks/D50pdiVl.js";var a=p("<h1>TODO!!!</h1>");function f(o){var r=a();t(o,r)}export{f as component};
