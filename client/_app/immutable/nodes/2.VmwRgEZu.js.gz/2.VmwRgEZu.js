import"../chunks/NZTpNUN0.js";import"../chunks/KI_y4nh-.js";import{B as p,C as t}from"../chunks/D7Q30rfQ.js";var a=p("<h1>/</h1>");function h(o){var r=a();t(o,r)}export{h as component};
