import"../chunks/NZTpNUN0.js";import"../chunks/Dmj1l2Xz.js";import{B as p,C as t}from"../chunks/Dkbj-q8P.js";var a=p("<h1>/</h1>");function h(o){var r=a();t(o,r)}export{h as component};
