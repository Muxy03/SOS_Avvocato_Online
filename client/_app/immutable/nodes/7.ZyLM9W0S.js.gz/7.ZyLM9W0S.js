import"../chunks/DsnmJJEf.js";import"../chunks/BYxMzdyx.js";import{f as p,b as t}from"../chunks/7vUO3RyR.js";var a=p("<h1>TODO!!!</h1>");function f(o){var r=a();t(o,r)}export{f as component};
